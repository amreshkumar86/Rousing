import { Component } from '@angular/core';

@Component({
    selector: 'footer',
    template: require('./footer.html'),
    styles: [require('./footer.css')]
})
export class FooterComponent {}
