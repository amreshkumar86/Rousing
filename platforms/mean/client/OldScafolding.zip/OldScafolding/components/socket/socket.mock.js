'use strict';

export class SocketServiceStub {
    syncUpdates() {}
    unsyncUpdates() {}
}
