export default class Primus {}
