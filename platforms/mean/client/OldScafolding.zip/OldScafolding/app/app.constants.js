export default from '../../server/config/environment/shared';

